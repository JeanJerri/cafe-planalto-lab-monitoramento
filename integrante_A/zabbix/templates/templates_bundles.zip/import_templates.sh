#!/bin/bash
set -uo pipefail

check_util() {
  command -v "$1" &>/dev/null && return
  cat <<EOF
Utility '$1' not found. Please install it.
-------------------------------------
Debian/Ubuntu:      sudo apt install $1
Fedora/CentOS/RHEL: sudo dnf install $1
Arch Linux:         sudo pacman -S $1
macOS (Homebrew):   brew install $1
-------------------------------------
EOF
  exit 1
}

check_util curl
check_util jq

if [ $# -ne 3 ] || [ -z "$1" ] || [ -z "$2" ] || [ -z "$3" ]; then
  echo "Usage: $0 <TEMPLATES_DIR> <ZABBIX_URL> <AUTH_TOKEN>"
  exit 1
fi

TEMPLATES_DIR=$1
ZABBIX_URL="${2%/}/api_jsonrpc.php"
AUTH_TOKEN=$3

RULES='{
  "hosts":              {"createMissing":true,"updateExisting":true},
  "templates":          {"createMissing":true,"updateExisting":true},
  "templateLinkage":    {"createMissing":true,"deleteMissing":true},
  "discoveryRules":     {"createMissing":true,"updateExisting":true,"deleteMissing":true},
  "items":              {"createMissing":true,"updateExisting":true,"deleteMissing":true},
  "triggers":           {"createMissing":true,"updateExisting":true,"deleteMissing":true},
  "graphs":             {"createMissing":true,"updateExisting":true,"deleteMissing":true},
  "maps":               {"createMissing":true,"updateExisting":true},
  "images":             {"createMissing":true,"updateExisting":true},
  "valueMaps":          {"createMissing":true,"updateExisting":true},
  "templateDashboards": {"createMissing":true,"updateExisting":true},
  "mediaTypes":         {"createMissing":true,"updateExisting":true}
}'

total=0
failed=0

while IFS= read -r -d '' FILE; do
  total=$((total + 1))
  echo "Importing file: ${FILE}..."

  if ! RESPONSE=$(jq -Rs --argjson rules "$RULES" \
        '{jsonrpc:"2.0", method:"configuration.import",
          params:{format:"yaml", source:., rules:$rules}, id:1}' "$FILE" |
      curl -sS --fail-with-body -X POST \
        -H "Content-Type: application/json" \
        -H "Authorization: Bearer $AUTH_TOKEN" \
        --data-binary @- "$ZABBIX_URL"); then
    echo "HTTP/network error for ${FILE}: ${RESPONSE}"
    failed=$((failed + 1))
    echo "---"
    continue
  fi

  if echo "$RESPONSE" | jq -e '.result == true' >/dev/null 2>&1; then
    echo "Successfully imported ${FILE}."
  else
    ERR=$(echo "$RESPONSE" | jq -r '[.error.message, .error.data] | map(select(. != null and . != "")) | join(": ")' 2>/dev/null)
    echo "Import error ${FILE}: ${ERR:-$RESPONSE}"
    failed=$((failed + 1))
  fi
  echo "---"
done < <(find "$TEMPLATES_DIR" -type f -name "*.yaml" -print0 | sort -zV)

echo "Processed: $total, failed: $failed"
[ "$total" -gt 0 ] || { echo "No YAML files found in $TEMPLATES_DIR"; exit 1; }
[ "$failed" -eq 0 ]